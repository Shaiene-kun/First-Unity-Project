﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; //Needed to use UI elements

public class EndGameScore : MonoBehaviour
{
    //Writes the score to the ending panel

    int score;
    public Text uiScore;
    UiTotems uiTotemsReference;
    Timer timerReference;

    public void ShowScore()
    {
        //Pausing the timer in order to prevent the restart of the scene
        timerReference = GameObject.FindObjectOfType<Timer>();
        timerReference.SetTimerOn(false);

        //Putting the score value on the Score Panel
        uiTotemsReference = GameObject.FindObjectOfType<UiTotems>(); //Getting the UiTotems GameObject 
        score = uiTotemsReference.GetTotalTotems();
        uiScore.text = score.ToString();
    }
}
