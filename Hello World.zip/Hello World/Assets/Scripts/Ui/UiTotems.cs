﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; //This is needed for manipulating UI elemets

public class UiTotems : MonoBehaviour
{
    public Text uiTotalTotems; //Contains various info about the text, like font, size, postion and the text itself
    private int totalTotems;
    string finalText;

    public int GetTotalTotems()
    {
        return totalTotems;  
    }

    // Start is called before the first frame update
    private void Start()
    {
        //Finds number of totems by counting how many GameObjects with the "Totem" tag exists
        /*totems = GameObject.FindGameObjectsWithTag("Totem");
        remainingTotems = totems.Length;
        uiRemainingTotems.text = remainingTotems.ToString(); //Writing the number of totems on UI*/
        uiTotalTotems.text = "0";
        
    }

    //Changes the number of untouched totems after one of them is touched
    public void UITotemUpdate()
    {
        totalTotems += 1;
        finalText =  totalTotems.ToString();
        uiTotalTotems.text = finalText;
    }

    
}
