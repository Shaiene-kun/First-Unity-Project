﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; //Needed to use UI elements

public class Timer : MonoBehaviour
{
    //Creates timer for the player to score

    float timer;
    private bool timerOn;
    public Text uiTimer;
    string finalText;

    public void SetTimerOn(bool boolean)
    {
        timerOn = boolean;
    }
    
    // Start is called before the first frame update
    void Start()
    {
        timer = 10f;
        timerOn = true;
    }

    // Update is called once per frame
    void Update()
    {

        if (timerOn == true)
        {
            CountDown();
            //Restarts the scene if the timer is lower than 0
            if (timer < 0)
            {
                CallRestart();
            }

        }
    }
   
    //Calls the restart method in the restart Script
    void CallRestart()
    {
        Restart restart = FindObjectOfType<Restart>();
        restart.GameEnd();
    }

    //Changes the timer value on UI
    void CountDown()
    {
        timer -= Time.deltaTime;
        finalText = timer.ToString("0");
        uiTimer.text = finalText;
    }
}
