﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleSpawner : MonoBehaviour
{
    
    GameObject player;
    public GameObject totemPrefab; //Referencing via the GUI editor
    Vector3 playerPosition;
    public Vector3 offset, position;
    public float xPosition, yPosition, zPosition, zOffset, spawnerRange;
    bool positiveSwitch;

    // Start is called before the first frame update
    void Start()
    {
        //Refencing player via Tag
        player = GameObject.FindGameObjectWithTag("Player");
        //Starting the offset of spawner
        positiveSwitch = true;
        //Defining positions and range of movement
        xPosition = 0f;
        yPosition = 1.62f;
        zPosition = 0f;
        zOffset = 200f;
        spawnerRange = 30f;
        position.Set(xPosition, yPosition, zPosition);
        offset.Set(0, 0, zOffset);
    }

    // Update is called once per frame
    void Update()
    {
        //playerPosition = player.transform.position;
        MoveSideways();
        MoveAlongPlayer();
        SpawnTotem();
    }

    void MoveSideways()
    {
        void changePosition()
        {
            position.Set(xPosition, yPosition, zPosition);
            this.transform.position = position;
        }

        //Debug.Log("Move Sideways");
        //Moves the Spawner from (x -25) to (x +25) and vice-versa, repeatedly
        if (positiveSwitch == true)
        {
           // Debug.Log("Positive true");
            if (xPosition < (spawnerRange / 2))
            {
               // Debug.Log("X Position: " + xPosition + " < " + (spawnerRange / 2));
                //Setting spawner position
                xPosition++;
                changePosition();
            }
            else
            {
                positiveSwitch = false; //From now on, xPosition will have its value decreased
            }
        }
        else
        {
            //Debug.Log("Positive false");
            if (xPosition > (spawnerRange / -2))
            {
                //Setting spawner position
                xPosition--; 
                changePosition();
            }
            else
            {
                positiveSwitch = true; //From now on, xPosition will have its value increased
            }
        }
        //Debug.Log("Spawner X Position: " + this.transform.position.x);
    }

    void MoveAlongPlayer()
    {
        //Offseting the spawner to a fixed distance from the player
        playerPosition = player.transform.position;
        offset.Set(0, 0, playerPosition.z + zOffset);
        this.transform.position += offset; 
    }

    void SpawnTotem()
    {
        //Instantiates totems 
        bool RNG()
        {
            int rand = (int)Random.Range(1f, 30f);
            if (rand == 1f)
                return true;
            else
                return false;
        }

        if ( RNG() )
        {
            Instantiate(totemPrefab, this.transform.position, Quaternion.identity);
        }
       
    }
}
