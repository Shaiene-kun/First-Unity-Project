﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class StartMenu : MonoBehaviour
{
    //Manages the quitting and starting events
    public void Quit()
    {
        Debug.Log("Goodbye World!");
        Application.Quit();
    }

    public void StartGame()
    {
        Debug.Log("Hello World!");
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }
}
