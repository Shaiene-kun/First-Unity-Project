﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AutoRemove : MonoBehaviour
{
    //Deletes obstacles after they get behind the camera

    GameObject cam, totem;
    float camZPosition, totemZPosition;

    void Start()
    {

        cam = GameObject.FindGameObjectWithTag("MainCamera");
        totem = gameObject; //Returns the GameObject this component(Script) is attached to

    }

    // Update is called once per frame
    void Update()
    {

        camZPosition = cam.transform.position.z;
        totemZPosition = totem.transform.position.z;

        if(camZPosition > totemZPosition)
        {
            Destroy(totem);
        }

    }

}
