﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GroundOffset : MonoBehaviour
{
    GameObject player;
    Vector3 playerPosition, groundPosition;
    public Vector3 offset, groundOffset;
    
    //References the player using the FindWithTag method, and makes the ground seek it on the z axis
    
    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.FindWithTag("Player");
    }

    // Update is called once per frame
    void Update()
    {

        playerPosition = player.transform.position;
        //The offset vector 3 is receiving: Set(0 ,0 + 1,0)
        offset.Set(-playerPosition.x, -playerPosition.y + 1f, 0f);
        groundOffset = playerPosition + offset;
        this.transform.position = groundOffset;
    }
}
