﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Veryfing player collision with another objects

public class PlayerCollision : MonoBehaviour
{

    int counter;
    public UiTotems totems; //Instance of the UiTotems class, for calling the method that updates the UI

    void Start()
    {
        totems = GameObject.FindObjectOfType(typeof(UiTotems)) as UiTotems; //Referencing the GameObject that shows the value of totems remaining
        counter = 0;
    }
    //This method is called when the RigidBody of the GameObject that has this script as a component, collides with the RigidBody of another GameObject and stores the info of the collision on a var
    void OnCollisionEnter(Collision collisionInfo)
    {
        if(collisionInfo.collider.tag == "Totem") //Veryfies if the collider has the tag
        {
            counter++;
            totems.UITotemUpdate(); //Calls the method that updates the UI info about totems touched
        }

        if(collisionInfo.collider.tag == "Totem")
        {
            //player
        }

    }
}
