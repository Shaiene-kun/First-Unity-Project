﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{

    public Rigidbody playerRigidBody; //References the Rigidbody component from the Player GameObject
    public float forceXAxis, forceYAxis, forceZAxis; //Amount of force on each axis
    public Vector3 autoMovement;
    public float sidewaysForce;//Amount of force for the user movement 
    float lastFrame; //Used to even the amount of physics calculations based on FPS
    int playerHealth;

    // Start is called before the first frame update
    void Start()
    {
        string helloWorld = "Hello World";
        Debug.Log(helloWorld);
        autoMovement.Set(0, 0, 80);
        //playerHealth = 2;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        PlayerMovement();
    }

    void PlayerMovement()
    {
        lastFrame = Time.deltaTime; //Stores the amount of seconds since the last frame
        //playerRigidBody.AddForce(forceXAxis * lastFrame , forceYAxis * lastFrame, forceZAxis * lastFrame); //Auto player movement
        playerRigidBody.transform.position += autoMovement * Time.deltaTime;
        //User player movement
        if (Input.GetKey("d"))
        {
            playerRigidBody.AddForce(sidewaysForce, 0, 0, ForceMode.VelocityChange);
        }
        if (Input.GetKey("a"))
        {
            playerRigidBody.AddForce(-sidewaysForce, 0, 0, ForceMode.VelocityChange);
        }
        //Showing options for restarting the scene if the player falls
        if (playerRigidBody.position.y < -2)
        {
            FindObjectOfType<Restart>().GameEnd(); //Referencing the Restart script via the FindObjectOfType meth
        }
    }


}

