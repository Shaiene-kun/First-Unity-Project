﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement; //This is needed for manipulating Scenes

public class Restart : MonoBehaviour
{
    float restartDelay = 5f;
    bool end = false;
    EndGameManager endGameManager;
    public void GameEnd()
    {
        if (end == false)
        {
            end = true;
            endGameManager = FindObjectOfType<EndGameManager>();
            endGameManager.SetGameEnded(true);
            Invoke("RestartScene",restartDelay);
        }
    }

    public void RestartScene ()
    {
        //SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }

    public void CreditsScene()
    {
        //SceneManager.LoadScene(SceneManager.CreditsScene);
    }

}
