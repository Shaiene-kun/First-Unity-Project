﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndGameManager : MonoBehaviour
{
    //Manages the EndGame state 

    private bool gameEnded;
    public GameObject EndGameUI;
    EndGameScore egs;
    void Start()
    {
        gameEnded = false;
    }

    public void SetGameEnded(bool end)
    {
        gameEnded = end;
        
        if(gameEnded == true)
        {
            EndGame();
        }
    }

    public void EndGame()
    {
            egs = GameObject.FindObjectOfType<EndGameScore>();
            EndGameUI.SetActive(true);
            egs.ShowScore();    

    }

}
